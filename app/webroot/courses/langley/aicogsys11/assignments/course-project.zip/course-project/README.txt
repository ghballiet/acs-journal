======================================================================
		   CSE 471 / CSE 598 Course Project
			     Spring 2011
======================================================================

Instructions for this project may be found online at
http://bit.ly/hUlKql. Additionally, a list of concepts, percepts and
actions provided by this environment may be found online at
http://bit.ly/eGW4rO. 

Below is a list of files you will need to edit for this project.

 - agent-types/all.lisp: Define any concepts and skills which should
   be available to all agents in this file. 

 - agent-types/capitalist.lisp: Define any concepts and skills for
   capitalists here. Additionally, you may define the amount of money
   the agent starts with, its starting price, and the limits to buy
   and sell offers it will accept.

 - agent-types/collector.lisp: Define any concepts and skills for
   collectors here. Additionally, you may define the amount of money
   the agent starts with, its starting price, and the limits to sell
   offers it will accept.

 - agent-types/innocent.lisp: Define any concepts and skills for
   innocents here. Additionally, you may define the amount of money
   the agent starts with, its starting price, and the limits to buy
   offers it will accept. 

If you wish to make changes to the starting positions of agents or to
the environment, edit the appropriate files in agents/. 
