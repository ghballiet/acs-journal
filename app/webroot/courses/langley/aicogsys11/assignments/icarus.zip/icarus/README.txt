======================================================================
 Running Icarus (on the Blocksworld domain) - Exercise 2
======================================================================
 1. Compiling Icarus
----------------------------------------------------------------------
 To compile Icarus on your machine, start a Lisp interpreter in the
 current directory, and run:

			   (load "compile")
 
 This will compile the Icarus architecture for your machine.

======================================================================
 2. Running Icarus
----------------------------------------------------------------------
 To run Icarus on your machine, start a Lisp interpreter in the
 directory "icarus-3.0/" and run:

			   (load "loader")
 
 Once you are ready to test the concepts you have defined, you can
 initialize the Blocksworld with one of the following configurations:

 1. All blocks on the table, with none adjacent
 2. A tower composed of A, B, and C, with D on the table separately
 3. A tower composed of A, B, and C, with another composed of D and E
 4. A situation in which blocks A, B, C, and D are adjacent on the
    table. 
 5. A situation in which blocks A, B, C, and D are adjacent on the
    table and aligned by height from left to right.
 6. A situation in which blocks A, B, C, and D are adjacent on the
    table, aligned by height from left to right, and have alternating
    light and dark shades.
 7. A pyramid composed of the blocks A, B, C, and D.
 8. A pyramid composed of A, B, C, and D in which the blocks have
    alternating shades.
 9. A tower composed of A, B, C, D, and E. 

 To initialize the Blocksworld with one of these configurations, run:

			       (test X)
 
 where X is the number of the configuration you wish to test. For
 example, if you wanted to test configuration 8, you would run:

			       (test 8)

======================================================================
 3. Writing the Concepts
----------------------------------------------------------------------
 Make sure to edit ONLY the blockcon.lisp file which is symlinked in
 the top directory. If the symlink doesn't work on your machine, or if
 your changes do not seem to have an effect, edit the file

	     icarus-3.0/Blocks/blockcon.lisp
 
 instead.
